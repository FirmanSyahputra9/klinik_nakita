<x-layouts.app :title="__('Data Dokter')">

    @livewire('pages.admin.data-dokter')

</x-layouts.app>
