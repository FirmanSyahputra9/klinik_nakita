<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Hasil Lab')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Hasil Lab'))]); ?>

    <div class="p-6" x-data="labResult">

        <h1 class="text-2xl font-semibold text-gray-800 mb-6">
            Hasil Pemeriksaan Laboratorium
        </h1>

        <div class="bg-white p-6 rounded-xl shadow-md space-y-10">

            <?php $__currentLoopData = $hasil ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="space-y-4">

                <!-- Judul Jenis Pemeriksaan -->
                <div>
                    <!-- <h3 class="text-lg font-semibold text-gray-700">
                        <?php echo e($item->lab->first()->jenis->jenis_pemeriksaan ?? '-'); ?>

                    </h3> -->
                    <div class="flex items-center gap-1">
                        <svg class="w-5 h-5 flex-shrink-0 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>

                        <p class="text-sm text-gray-600">
                            <?php echo e($item->created_at->format('d F Y')); ?>

                        </p>
                    </div>

                </div>

                <!-- LOOP KATEGORI -->
                <?php $__currentLoopData = $item->lab->groupBy('jenis.jenis_pemeriksaan') ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="space-y-2">

                    <!-- Nama Kategori (Jika Mau Dipakai) -->
                    

                    <!-- WRAPPER RESPONSIVE -->
                    <div class="overflow-x-auto rounded-lg border border-gray-200">

                        <table class="min-w-full text-sm">

                            <thead class="bg-blue-50 text-gray-700">
                                <tr>
                                    <th class="px-4 py-2 text-left">Pemeriksaan</th>
                                    <th class="px-4 py-2 text-center">Hasil</th>
                                    <th class="px-4 py-2 text-center">Nilai Normal</th>
                                    <th class="px-4 py-2 text-center">Status</th>
                                </tr>
                            </thead>

                            <tbody class="divide-y divide-gray-200">

                                <?php $__currentLoopData = $details ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr class="text-center">

                                    <!-- Nama Pemeriksaan -->
                                    <td class="px-4 py-2 text-left">
                                        <?php echo e($detail->jenis->jenis_pemeriksaan); ?>

                                    </td>

                                    <!-- Nilai Pemeriksaan -->
                                    <td class="px-4 py-2">
                                        <span class="
                                                        <?php if($detail->nilai < $detail->jenis->normal_min): ?>
                                                            text-red-600
                                                        <?php elseif($detail->nilai > $detail->jenis->normal_max): ?>
                                                            text-red-600
                                                        <?php else: ?>
                                                            text-green-600
                                                        <?php endif; ?>
                                                    ">
                                            <?php echo e($detail->nilai); ?>

                                        </span>
                                        <?php echo e($detail->jenis->satuan); ?>

                                    </td>

                                    <!-- Nilai Normal -->
                                    <td class="px-4 py-2">
                                        <?php echo e($detail->jenis->normal_min); ?> -
                                        <?php echo e($detail->jenis->normal_max); ?>

                                        <?php echo e($detail->jenis->satuan); ?>

                                    </td>

                                    <!-- Status -->
                                    <td class="px-4 py-2 font-semibold
                                                    <?php if($detail->nilai < $detail->jenis->normal_min): ?>
                                                        text-red-600
                                                    <?php elseif($detail->nilai > $detail->jenis->normal_max): ?>
                                                        text-red-600
                                                    <?php else: ?>
                                                        text-green-600
                                                    <?php endif; ?>
                                                ">
                                        <?php if($detail->nilai < $detail->jenis->normal_min): ?>
                                            Rendah
                                            <?php elseif($detail->nilai > $detail->jenis->normal_max): ?>
                                            Tinggi
                                            <?php else: ?>
                                            Normal
                                            <?php endif; ?>
                                    </td>

                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>

                    </div> <!-- end responsive wrapper -->

                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

    <!-- Alpine.js Data Tetap -->
    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('labResult', () => ({
                results: {},
                statusText() {},
                statusColor() {},
            }));
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?><?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/pages/pasien/hasil.blade.php ENDPATH**/ ?>