<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Resep')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Resep'))]); ?>

    <div class="max-w-4xl mx-auto bg-white p-6 rounded-2xl shadow">
        <h1 class="text-2xl font-semibold text-gray-800 mb-6">Tulis Resep Baru</h1>

        <form method="POST" action="<?php echo e(route('resep.store')); ?>">
            <?php echo csrf_field(); ?>

            <!-- PILIH ANTRIAN -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">Pilih Antrian</label>
                <select name="antrian_id" id="antrianSelect" class="w-full border border-gray-300 rounded-lg px-4 py-2">
                    <option value="" class="!important text-gray-400 bg-transparent hover:bg-none">-- Pilih Antrian --</option>
                    <?php $__currentLoopData = $antrian??[]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($a->id); ?>" data-nama="<?php echo e($a->pasien->name??'-'); ?>"
                            data-umur="<?php echo e($a->pasien->umur??'-'); ?>" data-jenis="<?php echo e($a->pasien->gender_label??'-'); ?>"
                            data-diagnosa="<?php echo e($a->data_pemeriksaan->diagnosa??'-'); ?>">
                            <?php echo e($a->pasien->name??'-'); ?> - (<?php echo e($a->kode_antrian??'-'); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Nama Pasien -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">Nama Pasien</label>
                <input id="namaPasien" type="text"
                    class="w-full border bg-gray-100 border-gray-300 rounded-lg px-4 py-2" readonly>
            </div>

            <!-- Umur -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">Umur</label>
                <input id="umurPasien" type="text"
                    class="w-full border bg-gray-100 border-gray-300 rounded-lg px-4 py-2" readonly>
            </div>

            <!-- Jenis Kelamin -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">Jenis Kelamin</label>
                <input id="jenisPasien" type="text"
                    class="w-full border bg-gray-100 border-gray-300 rounded-lg px-4 py-2" readonly>
            </div>

            <!-- Diagnosa -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">Diagnosa</label>
                <input id="diagnosa" type="text"
                    class="w-full border bg-gray-100 border-gray-300 rounded-lg px-4 py-2" readonly>
            </div>

            <!-- RESEP OBAT -->
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">Resep Obat</label>

                <div id="obat-list" class="space-y-4">
                    <div class="grid grid-cols-6 gap-3 text-xs">

                        <select name="obat[0][obat_id]" id="obatSelect"
                            class="border border-gray-300 rounded-lg px-3 py-2">
                            <option value="">Pilih Obat...</option>
                            <?php $__currentLoopData = $obats??[]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($obat->id??"-"); ?>" obat-harga="<?php echo e($obat->harga??"-"); ?>">
                                    <?php echo e($obat->nama??"-"); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <input type="text" name="obat[0][dosis]" placeholder="Dosis"
                            class="border border-gray-300 rounded-lg px-3 py-2">
                        <input type="text" name="obat[0][frekuensi]" placeholder="Frekuensi"
                            class="border border-gray-300 rounded-lg px-3 py-2">

                        <div class="flex gap-2">
                            <label><input type="checkbox" name="obat[0][waktu_konsumsi][]" value="Pagi"> Pagi</label>
                            <label><input type="checkbox" name="obat[0][waktu_konsumsi][]" value="Siang"> Siang</label>
                            <label><input type="checkbox" name="obat[0][waktu_konsumsi][]" value="Sore"> Sore</label>
                            <label><input type="checkbox" name="obat[0][waktu_konsumsi][]" value="Malam"> Malam</label>
                        </div>

                        <input type="number" name="obat[0][kuantitas]" placeholder="Kuantitas"
                            class="border border-gray-300 rounded-lg px-3 py-2">
                        <input type="text" id="obatHarga" name="obat[0][harga]" placeholder="Harga (Auto)"
                            class="border border-gray-300 rounded-lg px-3 py-2 bg-gray-100" readonly>
                    </div>
                </div>

                <button type="button" id="tambah-obat"
                    class="mt-3 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg text-sm font-medium">
                    + Tambah Obat
                </button>
            </div>

            <div class="flex justify-end">
                <button type="submit"
                    class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-lg shadow">
                    Simpan Resep
                </button>
            </div>

        </form>
    </div>

    <script>
        // AUTO UPDATE PASIEN
        document.getElementById('antrianSelect').addEventListener('change', function() {
            const selected = this.selectedOptions[0];
            document.getElementById('namaPasien').value = selected.dataset.nama || '';
            document.getElementById('umurPasien').value = selected.dataset.umur || '';
            document.getElementById('jenisPasien').value = selected.dataset.jenis || '';
            document.getElementById('diagnosa').value = selected.dataset.diagnosa || '';
        });

        // AUTO UPDATE OBAT
        document.getElementById('obatSelect').addEventListener('change', function() {
            const selected = this.selectedOptions[0];
            document.getElementById('obatHarga').value = selected.getAttribute('obat-harga') || '';
        });

        // TAMBAH ROW OBAT
        let obatIndex = 1;

        document.getElementById('tambah-obat').addEventListener('click', () => {
            const container = document.getElementById('obat-list');
            const row = document.createElement('div');
            row.classList = "grid grid-cols-6 gap-3 text-xs";

            // buat option obat
            let obatOptions = '<option value="">Pilih Obat...</option>';
            const obats = <?php echo json_encode($obats, 15, 512) ?>;
            obats.forEach(o => {
                obatOptions += `<option value="${o.id}" obat-harga="${o.harga_jual}">${o.nama}</option>`;
            });

            // checkbox waktu konsumsi
            let waktuHTML = `
                <div class="flex gap-2">
                    <label><input type="checkbox" name="obat[${obatIndex}][waktu_konsumsi][]" value="Pagi"> Pagi</label>
                    <label><input type="checkbox" name="obat[${obatIndex}][waktu_konsumsi][]" value="Siang"> Siang</label>
                    <label><input type="checkbox" name="obat[${obatIndex}][waktu_konsumsi][]" value="Sore"> Sore</label>
                    <label><input type="checkbox" name="obat[${obatIndex}][waktu_konsumsi][]" value="Malam"> Malam</label>
                </div>
            `;

            row.innerHTML = `
                <select name="obat[${obatIndex}][obat_id]" class="border border-gray-300 rounded-lg px-3 py-2">
                    ${obatOptions}
                </select>
                <input type="text" name="obat[${obatIndex}][dosis]" placeholder="Dosis" class="border border-gray-300 rounded-lg px-3 py-2">
                <input type="text" name="obat[${obatIndex}][frekuensi]" placeholder="Frekuensi" class="border border-gray-300 rounded-lg px-3 py-2">
                ${waktuHTML}
                <input type="number" name="obat[${obatIndex}][kuantitas]" placeholder="Kuantitas" class="border border-gray-300 rounded-lg px-3 py-2">
                <input type="text" name="obat[${obatIndex}][harga]" placeholder="Harga (Auto)" class="border border-gray-300 rounded-lg px-3 py-2 bg-gray-100" readonly>
            `;

            container.appendChild(row);
            obatIndex++;
        });
    </script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/pages/dokter/resep.blade.php ENDPATH**/ ?>