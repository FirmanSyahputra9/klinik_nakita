<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Tindakan Pasien')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Tindakan Pasien'))]); ?>

    <!-- Header -->
    <div class="mb-8">
        <h1 class="text-3xl font-bold text-gray-800">Data Pasien</h1>
        <p class="text-gray-600 mt-1">Selamat Datang, dr. Aditya Hutagalung</p>
    </div>

    <!-- Main Card -->
    <div class="bg-white rounded-xl shadow-sm p-6">
        <h2 class="text-xl font-semibold text-gray-800 mb-6">Data Pasien</h2>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

            <!-- Left card -->
            <div class="lg:col-span-1">
                <div class="bg-gradient-to-br from-green-600 to-green-700 rounded-2xl p-6 text-white shadow-lg">
                    <div class="space-y-3">
                        <div>
                            <h3 class="text-2xl font-bold"><?php echo e($data->pasiens->no_rm); ?></h3>
                            <p class="text-xl font-semibold mt-1"><?php echo e($data->pasiens->name); ?></p>
                        </div>

                        <div class="space-y-2 text-sm pt-4 border-t border-green-500">
                            <p><span class="font-medium">Tgl Bergabung:</span> <?php echo e($data->pasiens->create_at); ?></p>
                            <p><span class="font-medium">NIK:</span> <?php echo e($data->pasiens->nik); ?></p>
                            <p><span class="font-medium">JK:</span> <?php echo e($data->pasiens->gender_label); ?></p>
                            <p><span class="font-medium">Tanggal Lahir:</span>
                                <?php echo e($data->pasiens->birth_date_formatted); ?>

                            </p>
                            <p><span class="font-medium">Umur:</span> <?php echo e($data->pasiens->umur); ?> Tahun</p>
                            <p><span class="font-medium">No. Telp:</span> <?php echo e($data->pasiens->phone); ?></p>
                            <p><span class="font-medium">Alamat:</span> <?php echo e($data->pasiens->address); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="border rounded mb-4 p-4 bg-white shadow">

                <h3 class="font-semibold text-lg text-gray-800">
                    Tambah Pemeriksaan
                </h3>

                <p class="text-sm text-gray-600 mb-3">
                </p>

                <form action="<?php echo e(route('jenis-pemeriksaan.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <label class="font-medium text-gray-700">Nama Pemeriksaan</label>
                    <input list="listPemeriksaan" name="new_pemeriksaan" class="w-full border rounded px-3 py-2"
                        placeholder="Pilih atau ketik...">
                    <datalist id="listPemeriksaan">
                        <?php $__currentLoopData = $jenisPemeriksaans ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jenis->jenis_pemeriksaan); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>

                    <div class="grid grid-cols-2 gap-4">

                        <div class="mb-3">
                            <label class="font-medium text-gray-700">Nilai Normal Minimal</label>
                            <input type="text" name="normal_min" class="w-full border rounded px-3 py-2"
                                placeholder="Masukkan nilai...">
                        </div>

                        <div class="mb-3">
                            <label class="font-medium text-gray-700">Nilai Normal Maksimal</label>
                            <input type="text" name="normal_max" class="w-full border rounded px-3 py-2"
                                placeholder="Masukkan nilai...">
                        </div>
                    </div>

                    <label class="font-medium text-gray-700">Satuan</label>
                    <input list="listSatuan" name="new_satuan" class="w-full border rounded px-3 py-2"
                        placeholder="Pilih atau ketik...">

                    <datalist id="listSatuan">
                        <option value="mg/dL">
                        <option value="g/dL">
                        <option value="%">
                        <option value="/µL">
                        <option value="U/L">
                        <option value="Negatif">
                    </datalist>

                    <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">
                        Simpan
                    </button>

                </form>
            </div>
        </div>

        <form action="<?php echo e(route('data-pemeriksaan.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- kirim antrian_id -->
            <input type="hidden" name="antrian_id" value="<?php echo e($antrian->id); ?>">

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

                <!-- Form Alergi -->
                <div class="mt-10">
                    <h2 class="text-xl font-bold text-gray-900 mb-6">Form Alergi</h2>

                    <textarea name="alergi" rows="3" class="w-full border rounded p-3"
                        placeholder="Tulis alergi pasien (jika ada)..."><?php echo e($antrian->alergi->alergi ?? ''); ?></textarea>

                    <textarea name="reaksi" rows="3" class="w-full border rounded p-3 mt-3" placeholder="Reaksi alergi..."><?php echo e($antrian->alergi->reaksi ?? ''); ?></textarea>
                </div>

                <!-- Keluhan & Diagnosis -->
                <div class="mt-10">
                    <h2 class="text-xl font-bold">Keluhan Utama</h2>

                    <textarea name="keluhan" rows="3" class="w-full border rounded p-3" readonly><?php echo e($data->keluhan ?? ''); ?></textarea>

                    <textarea name="diagnosis" rows="3" class="w-full border rounded p-3 mt-3"
                        placeholder="Tuliskan diagnosis pasien..."><?php echo e($antrian->data_pemeriksaan->diagnosa ?? ''); ?></textarea>
                </div>

                <!-- Tindakan -->
                <div class="mt-10">
                    <h2 class="text-xl font-bold">Tindakan</h2>

                    <!-- Combo box nama tindakan -->
                    <input list="listNamaTindakan" name="nama_tindakan" class="w-full border rounded p-3"
                        value="<?php echo e($antrian->tindakan->nama_tindakan ?? ''); ?>"
                        placeholder="Pilih atau ketik nama tindakan...">
                    <datalist id="listNamaTindakan">
                        <?php $__currentLoopData = $jenisPemeriksaans ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($jp->jenis_pemeriksaan); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </datalist>

                    <!-- Combo box jenis tindakan -->
                    <input list="listJenisTindakan" name="jenis_tindakan" class="w-full border rounded p-3 mt-3"
                        value="<?php echo e($antrian->tindakan->jenis_tindakan ?? ''); ?>"
                        placeholder="Pilih atau ketik jenis tindakan...">
                    <datalist id="listJenisTindakan">
                        <option value="Rawat Jalan">
                        <option value="Rawat Inap">
                        <option value="Tindakan Kecil">
                        <option value="Tindakan Besar">
                        <option value="Laboratorium">
                        <option value="Radiologi">
                    </datalist>

                    <textarea name="catatan_tindakan" rows="3" class="w-full border rounded p-3 mt-3"
                        placeholder="Catatan tambahan (opsional)..."><?php echo e($antrian->tindakan->catatan ?? ''); ?></textarea>
                </div>

            </div>

            <div class="flex justify-end gap-3 mt-8 pt-6 border-t">
                <button type="submit" class="px-8 py-2 bg-blue-600 text-white rounded-lg">
                    Simpan Hasil
                </button>
            </div>
        </form>


        <div class="mt-10">
            <h2 class="text-xl font-bold text-gray-900 mb-6">Pemeriksaan Laboratorium</h2>

            <div class="overflow-x-auto bg-white rounded-xl shadow">
                <table class="min-w-full border border-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-3 border text-left text-gray-700 font-semibold">Pemeriksaan</th>
                            <th class="px-4 py-3 border text-left text-gray-700 font-semibold">Nilai Normal</th>
                            <th class="px-4 py-3 border text-left text-gray-700 font-semibold">Input Nilai</th>
                            <th class="px-4 py-3 border text-left text-gray-700 font-semibold">Catatan</th>
                            <th class="px-4 py-3 border text-center text-gray-700 font-semibold w-32">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $jenisPemeriksaans ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php

                                $hasil = $antrian->lab->firstWhere('jenis_pemeriksaan_id', $jenis->id);
                            ?>

                            <tr class="border">

                                <td class="px-4 py-3 border">
                                    <?php echo e($jenis->jenis_pemeriksaan); ?>

                                </td>

                                <td class="px-4 py-3 border font-medium text-gray-700">
                                    <?php echo e($jenis->normal_min); ?> ~ <?php echo e($jenis->normal_max); ?> <?php echo e($jenis->satuan); ?>

                                </td>

                                <form action="<?php echo e(route('pemeriksaan-lab.store')); ?>" method="POST"
                                    class="flex gap-2 items-center">
                                    <?php echo csrf_field(); ?>
                                    <td class="px-4 py-3 border">

                                        <input type="hidden" name="antrian_id" value="<?php echo e($antrian->id); ?>">
                                        <input type="hidden" name="jenis_pemeriksaan_id"
                                            value="<?php echo e($jenis->id); ?>">

                                        <div class="flex gap-2 items-center">
                                            <input type="text" name="nilai"
                                                class="w-full border rounded px-3 py-2" placeholder="Isi nilai..."
                                                value="<?php echo e($hasil->nilai ?? ''); ?>">
                                            <span><?php echo e($jenis->satuan); ?></span>
                                        </div>
                                        <div class="">
                                            <?php if($hasil?->nilai !== null): ?>
                                                <?php
                                                    $diff = 0;
                                                    $class = 'font-normal text-yellow-500';

                                                    if ($hasil->nilai < $jenis->normal_min) {
                                                        $diff = $jenis->normal_min - $hasil->nilai;
                                                        if ($diff >= 15) {
                                                            $class = 'font-extrabold text-red-600';
                                                        } elseif ($diff >= 10) {
                                                            $class = 'font-bold text-orange-700';
                                                        } elseif ($diff >= 5) {
                                                            $class = 'font-semibold text-orange-500';
                                                        } else {
                                                            $class = 'font-normal text-yellow-500';
                                                        }
                                                        $message = $jenis->jenis_pemeriksaan . ' Terlalu Rendah';
                                                    } elseif ($hasil->nilai > $jenis->normal_max) {
                                                        $diff = $hasil->nilai - $jenis->normal_max;
                                                        if ($diff >= 15) {
                                                            $class = 'font-extrabold text-red-600';
                                                        } elseif ($diff >= 10) {
                                                            $class = 'font-bold text-orange-700';
                                                        } elseif ($diff >= 5) {
                                                            $class = 'font-semibold text-orange-500';
                                                        } else {
                                                            $class = 'font-normal text-yellow-500';
                                                        }
                                                        $message = $jenis->jenis_pemeriksaan . ' Terlalu Tinggi';
                                                    } else {
                                                        $class = 'font-normal text-green-600';
                                                        $message = $jenis->jenis_pemeriksaan . ' Normal';
                                                    }
                                                ?>

                                                <span class="<?php echo e($class); ?>"><?php echo e($message); ?></span>
                                            <?php endif; ?>


                                        </div>
                                    </td>

                                    <td class="px-4 py-3 border">
                                        <textarea name="catatan" class="w-full border rounded px-3 py-2" placeholder="Catatan..."><?php echo e($hasil->catatan ?? ''); ?></textarea>
                                    </td>

                                    <td class="px-4 py-3 border text-center">
                                        <button type="submit"
                                            class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                                            Simpan
                                        </button>
                                    </td>
                                </form>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
    <?php if(session('refresh')): ?>
        <script>
            window.location.reload();
        </script>
    <?php endif; ?>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/pages/dokter/tindakan-pasien.blade.php ENDPATH**/ ?>