<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Appointment')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Appointment'))]); ?>

    <div x-data="{
        show: false,
        message: '',
        action: '',
    
        open(msg, act) {
            this.message = msg;
            this.action = act;
            this.show = true;
        },
        close() {
            this.show = false;
        }
    }" x-cloak>


        <!-- Header -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-2xl font-bold">Jadwal dan Appointment</h1>
                <p class="text-gray-500">Kelola jadwal dokter dan appointment pasien</p>
            </div>
            <div>
                <a href="<?php echo e(route('admin-create.index')); ?>"
                    class="px-6 py-3 bg-blue-500 text-white rounded-lg font-medium hover:bg-blue-600 transition">
                    Tambah Jadwal
                </a>
            </div>
        </div>

        <!-- Tabel -->
        <div class="overflow-x-auto bg-white shadow rounded-lg">
            <table class="w-full border border-gray-200 whitespace-nowrap">
                <thead class="bg-blue-50 text-gray-700">
                    <tr>
                        <th class="px-4 py-2 text-left">Kode</th>
                        <th class="px-4 py-2 text-left">Tanggal</th>
                        <th class="px-4 py-2 text-left ">Nama Pasien</th>
                        <th class="px-4 py-2 text-left">Dokter</th>
                        <th class="px-4 py-2 text-left">Keluhan</th>
                        <th class="px-4 py-2 text-left">Status</th>
                        <th class="px-4 py-2 text-center">Aksi </th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 text-gray-700">
                    <?php $__empty_1 = true; $__currentLoopData = $registrasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="py-2 px-4 text-gray-500"><?php echo e($reg->appointment_code); ?></td>
                            <td class="py-2 px-4 text-gray-500"><?php echo e($reg->tanggal_kunjungan); ?></td>
                            <td class="py-2 px-4 text-gray-500"><?php echo e($reg->pasiens->name); ?></td>
                            <td class="py-2 px-4 text-gray-500"><?php echo e($reg->dokters->name); ?></td>
                            <td class="py-2 px-4 text-gray-500"><?php echo e($reg->keluhan); ?></td>
                            <td class="py-2 px-4 text-gray-500">
                                <span
                                    class="<?php echo e($reg->status == 1 ? 'text-blue-600 bg-blue-100' : 'text-yellow-600 bg-yellow-100'); ?> px-2 py-1 rounded text-sm"><?php echo e($reg->status == 1 ? 'Acc' : 'Belum'); ?>

                                </span>
                            </td>
                            <!-- Tombol Aksi -->
                            <td class="px-4 py-2 text-center">
                                <div class="flex justify-center gap-2">
                                    <?php if($reg->status != 1): ?>
                                        <div class="flex-1">
                                            <button
                                                @click="open('Konfirmasi janji?', '<?php echo e(route('appointment.konfirmasi', $reg->id)); ?>')"
                                                class="bg-blue-500 text-white px-2 py-1 rounded hover:bg-blue-600 text-xs">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                    class="size-6">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="m4.5 12.75 6 6 9-13.5" />
                                                </svg>
                                            </button>
                                        </div>
                                    <?php else: ?>
                                        <div class="flex-1">
                                            <button disabled
                                                class="px-4 py-2 bg-gray-300 text-gray-500 rounded-lg opacity-50 cursor-not-allowed">
                                                <svg xmlns="http://www.w3.org/2000/svg" fill="none"
                                                    viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"
                                                    class="size-6">
                                                    <path stroke-linecap="round" stroke-linejoin="round"
                                                        d="m4.5 12.75 6 6 9-13.5" />
                                                </svg>
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                    <!-- Konfirmasi -->


                                    <!-- Selesai -->
                                    

                                    <!-- Batalkan -->
                                    

                                </div>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center py-6 text-gray-400">
                                Belum ada data pendaftaran
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div><?php echo e($registrasi->links()); ?></div>

        <!-- MODAL ALPINE -->
        <div x-show="show" class="fixed inset-0 bg-black/50 flex items-center justify-center" style="display:none">

            <div class="bg-white p-6 rounded-xl shadow-xl w-full max-w-md">

                <h2 class="text-lg font-semibold text-gray-800 mb-6 text-center" x-text="message"></h2>

                <form :action="action" method="POST" class="flex justify-center gap-4">
                    <?php echo csrf_field(); ?>

                    <button type="submit"
                        class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                        Iya
                    </button>

                    <button @click.prevent="close"
                        class="px-4 py-2 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition">
                        Batal
                    </button>
                </form>

            </div>

        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/pages/admin/appointment.blade.php ENDPATH**/ ?>