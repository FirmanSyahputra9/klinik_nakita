<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Jadwal')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Jadwal'))]); ?>
    <div class="p-6">
        <!-- Header -->
        <div class="flex justify-between items-center mb-6">
            <div>
                <h1 class="text-2xl font-bold text-gray-800">Jadwal Praktek</h1>
            </div>
        </div>

        <!-- Card Container -->
        <div class="bg-white border rounded-xl shadow-sm p-5">
            <h2 class="text-lg font-semibold text-gray-700 mb-4">Jadwal Praktek</h2>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                <?php $__empty_1 = true; $__currentLoopData = $dokterJadwals->jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div
                        x-data="{ editing: false, ket: '<?php echo e($jadwal->keterangan); ?>' }"
                        class="border rounded-xl p-4 shadow-sm hover:shadow-md transition"
                    >
                        <div class="flex justify-between items-center mb-2">
                            <h3 class="text-lg font-semibold text-gray-800"><?php echo e($jadwal->hari); ?></h3>
                            <!-- <span class="bg-green-100 text-green-700 text-sm px-3 py-1 rounded-full font-medium">
                                Aktif
                            </span> -->
                        </div>

                        <!-- Waktu -->
                        <p class="text-gray-600">
                            <?php echo e($jadwal->aktif_mulai->format('H:i')); ?> - <?php echo e($jadwal->aktif_selesai->format('H:i')); ?>

                        </p>

                        <!-- Keterangan -->
                        <div class="text-gray-600 mb-4">
                            <!-- Mode view -->
                            <p x-show="!editing" x-text="ket"></p>

                            <!-- Mode edit -->
                            <input
                                x-show="editing"
                                x-model="ket"
                                type="text"
                                class="border px-3 py-1 rounded-lg w-full"
                            >
                        </div>

                        <!-- Tombol -->
                        <button
                            x-show="!editing"
                            @click="editing = true"
                            class="bg-blue-100 hover:bg-blue-200 text-gray-600 font-medium w-full py-2 rounded-lg transition"
                        >
                            Edit Keterangan
                        </button>

                        <button
                            x-show="editing"
                            @click="editing = false"
                            class="bg-green-600 hover:bg-green-700 text-white font-medium w-full py-2 rounded-lg transition"
                        >
                            Konfirmasi
                        </button>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-center py-6 text-gray-400">Belum ada jadwal praktek</p>
                <?php endif; ?>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/pages/dokter/jadwal.blade.php ENDPATH**/ ?>