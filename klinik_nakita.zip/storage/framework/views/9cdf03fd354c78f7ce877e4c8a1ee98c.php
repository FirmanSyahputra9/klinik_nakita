<?php if (isset($component)) { $__componentOriginal5863877a5171c196453bfa0bd807e410 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5863877a5171c196453bfa0bd807e410 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.app','data' => ['title' => __('Detail Pasien')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Detail Pasien'))]); ?>
    <div class="max-w-5xl mx-auto mt-6 sm:mt-10 bg-white rounded-2xl shadow p-4 sm:p-8 ">

        <!-- Header -->
        <div class="flex flex-col sm:flex-row sm:items-center sm:space-x-4 mb-6 space-y-4 sm:space-y-0">
            <a href="<?php echo e(url()->previous()); ?>" class="text-gray-600 hover:text-gray-800 self-start sm:self-auto">
                <i class="fas fa-arrow-left text-lg"></i>
            </a>

            <div class="flex items-center space-x-4">
                <div class="w-16 h-16 bg-gray-200 rounded-full flex items-center justify-center">
                    <i class="fas fa-user text-gray-500 text-2xl"></i>
                </div>
                <div>
                    <h2 class="text-xl sm:text-2xl font-semibold"><?php echo e($user->pasien->name); ?></h2>
                    <p class="text-sm text-gray-600">
                        <?php echo e($user->pasien->gender_label ?? '-'); ?> ,
                        <?php echo e($user->pasien->umur ?? '-'); ?> Tahun
                        &nbsp;•&nbsp; Gol. Darah <?php echo e($user->pasien->gol_darah ?? '-'); ?>

                    </p>
                    <p class="text-sm text-gray-700 mt-1">
                        <span class="font-semibold">No. Telepon:</span> <?php echo e($user->pasien->phone ?? '-'); ?><br>
                        <span class="font-semibold">Email:</span> <?php echo e($user->email ?? '-'); ?>

                    </p>
                </div>
            </div>
        </div>

        <hr class="my-4">

        <!-- Konten Utama Scrollable -->
        <div class="space-y-10 pb-10">

            <!-- Informasi Pribadi (Tetap Ada Kontennya, Tidak Ada Navigasi) -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">

                <!-- Data Pribadi -->
                <div class="bg-gray-50 rounded-xl p-4">
                    <h3 class="font-semibold mb-2 text-gray-800">Data Pribadi</h3>
                    <div class="text-sm text-gray-700 space-y-1">
                        <p><span class="font-medium">NIK:</span> <?php echo e($user->pasien->nik ?? '-'); ?></p>
                        <p><span class="font-medium">Tanggal Lahir:</span> <?php echo e($user->pasien->tanggal_lahir ?? '-'); ?></p>
                        <p><span class="font-medium">Jenis Kelamin:</span> <?php echo e($user->pasien->gender_label ?? '-'); ?></p>
                        <p><span class="font-medium">Tanggal Registrasi:</span>
                            <?php echo e($user->create_at ?? '-'); ?></p>
                    </div>
                </div>

                <!-- Kontak & Alamat -->
                <div class="bg-gray-50 rounded-xl p-4">
                    <h3 class="font-semibold mb-2 text-gray-800">Kontak & Alamat</h3>
                    <div class="text-sm text-gray-700 space-y-1">
                        <p><span class="font-medium">No. Telepon:</span> <?php echo e($user->pasien->phone ?? '-'); ?></p>
                        <p><span class="font-medium">Email:</span> <?php echo e($user->email); ?></p>
                        <p><span class="font-medium">Alamat:</span> <?php echo e($user->pasien->alamat); ?></p>
                    </div>
                </div>

                <!-- Kontak Darurat -->
                <div class="bg-gray-50 rounded-xl p-4">
                    <h3 class="font-semibold mb-2 text-gray-800">Kontak Darurat</h3>
                    <div class="text-sm text-gray-700 space-y-1">
                        <p><span class="font-medium">Nama:</span> <?php echo e($user->kontak_darurat_nama ?? '-'); ?></p>
                        <p><span class="font-medium">Hubungan:</span> <?php echo e($user->kontak_darurat_hubungan ?? '-'); ?></p>
                        <p><span class="font-medium">No. Telepon:</span>
                            <?php echo e($user->kontak_darurat_no_telepon ?? '-'); ?></p>
                    </div>
                </div>

                <!-- Informasi Medis -->
                <div class="bg-gray-50 rounded-xl p-4">
                    <h3 class="font-semibold mb-2 text-gray-800">Informasi Medis</h3>
                    <div class="bg-white rounded-lg p-3 flex flex-wrap gap-2 border border-gray-200">
                        <?php if($riwayat): ?>
                            <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <span
                                    class="px-3 py-1 bg-gray-200 text-gray-800 rounded-full text-xs"><?php echo e($item->data_pemeriksaan->diagnosa ?? '-'); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <span class="px-3 py-1 bg-gray-200 text-gray-800 rounded-full text-xs">-</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="px-3 py-1 bg-gray-200 text-gray-800 rounded-full text-xs">-</span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>


            <!-- Hasil Lab (Dummy) -->
            <div class="bg-gray-50 rounded-xl p-4">
                <h3 class="font-semibold mb-4 text-gray-800">Hasil Pemeriksaan Lab</h3>
                <div class="overflow-x-auto">
                    <table class="w-full text-sm border border-gray-300 rounded-lg overflow-hidden">
                        <thead class="bg-gray-200 text-gray-700">
                            <tr>
                                <th class="px-4 py-2 text-left">Pemeriksaan</th>
                                <th class="px-4 py-2 text-left">Hasil</th>
                                <th class="px-4 py-2 text-left">Nilai Normal</th>
                                <th class="px-4 py-2 text-left">Status</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y">

                            <?php if($hasil): ?>
                                <?php $__empty_1 = true; $__currentLoopData = $hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php $__empty_2 = true; $__currentLoopData = $item->lab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <tr>
                                            <td class="px-4 py-2"><?php echo e($aitem->jenis->jenis_pemeriksaan ?? '-'); ?></td>
                                            <td class="px-4 py-2"><?php echo e($aitem->nilai ?? '-'); ?>

                                                <?php echo e($aitem->jenis->satuan ?? '-'); ?></td>
                                            <td class="px-4 py-2"><?php echo e($aitem->jenis->normal_min ?? '-'); ?> ~
                                                <?php echo e($aitem->jenis->normal_max ?? '-'); ?>

                                                <?php echo e($aitem->jenis->satuan ?? '-'); ?></td>
                                            <td class="px-4 py-2 text-green-600 font-semibold">Normal</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <tr>
                                            <td colspan="4" class="text-center py-6 text-gray-400">
                                                Belum ada hasil pemeriksaan
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-6 text-gray-400">
                                            Belum ada hasil pemeriksaan
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- Tombol Edit -->
        <div class="mt-8 text-center sm:text-right">
            <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                class="inline-flex items-center bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition">
                <i class="fas fa-edit mr-2"></i> Edit Data
            </a>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $attributes = $__attributesOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__attributesOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5863877a5171c196453bfa0bd807e410)): ?>
<?php $component = $__componentOriginal5863877a5171c196453bfa0bd807e410; ?>
<?php unset($__componentOriginal5863877a5171c196453bfa0bd807e410); ?>
<?php endif; ?>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/pages/admin/detail-pasien.blade.php ENDPATH**/ ?>