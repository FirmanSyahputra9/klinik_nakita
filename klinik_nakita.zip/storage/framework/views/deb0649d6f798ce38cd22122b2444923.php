<div>
    <div x-data="{
    show: false,
    message: '',
    action: '',
    spesialisFilter: '',

    open(message, act) {
        this.message = message;
        this.action = act;
        this.show = true;
    },
    close() { this.show = false; },
    confirm() { console.log('Action:', this.action); this.close(); },

    matchSpesialis(data) {
        if (this.spesialisFilter === '') return true;
        return data.toLowerCase() === this.spesialisFilter.toLowerCase();
    }
    }">

        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-semibold text-gray-800">Data Dokter</h1>

            <a href="<?php echo e(route('dokter.create')); ?>"
                class="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                Tambah Dokter
            </a>
        </div>
        <!-- Search -->
        <div class="mb-4">
            <input type="text" placeholder="Cari nama atau spesialisasi..." wire:model.live="search"
                class="w-full sm:w-1/3 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
        </div>

        <!-- Table -->
        <div class="bg-white rounded-lg shadow overflow-x-auto">
            <table class="min-w-full text-sm text-left text-gray-600 whitespace-nowrap">
                <thead class="bg-gray-100 text-gray-700 uppercase text-xs font-semibold">
                    <tr>
                        <th class="px-4 py-3">Nama Lengkap</th>
                        <th class="px-4 py-3">Spesialisasi</th>
                        <th class="px-4 py-3">No. Telepon</th>
                        <th class="px-4 py-3">Email</th>
                        <th class="px-4 py-3">Jadwal</th>
                        <th class="px-4 py-3 text-center">Status</th>
                        <th class="px-4 py-3 text-center">BErgabung Pada</th>
                        
                    </tr>
                </thead>
                <tbody>
                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $dokters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b hover:bg-gray-50">
                        <td
                            class="px-4 py-3 font-medium text-gray-800 min-w-32 max-w-32 overflow-x-auto thin-scroll">
                            <a href="<?php echo e(route('dokter.show', $data->dokter->id)); ?>">
                                <?php echo e($data->dokter->name); ?>

                            </a>
                        </td>
                        <td class="px-4 py-3 min-w-32 max-w-32 overflow-x-auto thin-scroll">
                            <?php echo e($data->dokter->spesialisasi); ?>

                        </td>
                        <td class="px-4 py-3 min-w-32 max-w-32 overflow-x-auto thin-scroll">
                            <?php echo e($data->dokter->phone); ?>

                        </td>
                        <td class="px-4 py-3 min-w-32 max-w-32 overflow-x-auto thin-scroll"><?php echo e($data->email); ?></td>
                        <td class="px-4 py-3 min-w-12 max-w-12 overflow-x-auto thin-scroll">
                            <?php echo e($this->formatHariRange($data->dokter->jadwals)); ?>

                        </td>

                        <td class="px-4 py-3 min-w-8 max-w-8 overflow-x-auto thin-scroll text-center"><?php echo e($data->dokter->status); ?></td>
                        <td class="px-4 py-3 min-w-12 max-w-12 overflow-x-auto thin-scroll text-center"><?php echo e($data->create_at); ?></td>

                        
                        <!-- Online -->
                        

                        <!-- Offline -->
                        

                        <!-- Delete -->
                        
                        
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center py-6 text-gray-400">
                            Belum ada data dokter
                        </td>
                    </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($dokters->links()); ?>

        </div>

        <!-- Modal Background -->
        <div x-show="show" x-transition.opacity @click.self="close"
            class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center
                z-50 px-4"
            style="display:none">

            <div x-show="show" x-transition.scale.origin.center
                class="bg-white p-6 rounded-xl shadow-xl w-full max-w-md">

                <h2 class="text-lg font-semibold text-gray-800 mb-6 text-center" x-text="message"></h2>

                <div class="flex justify-center gap-4">
                    <button @click="confirm"
                        class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
                        Iya
                    </button>

                    <button @click="close"
                        class="px-4 py-2 bg-gray-400 text-white rounded-lg hover:bg-gray-500 transition">
                        Batal
                    </button>
                </div>

            </div>
        </div>

    </div>
</div>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/livewire/pages/admin/data-dokter.blade.php ENDPATH**/ ?>