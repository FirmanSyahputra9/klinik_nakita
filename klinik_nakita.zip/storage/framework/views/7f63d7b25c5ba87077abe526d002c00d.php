<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Klinik Nakita</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-50 text-gray-800">

    <!-- Sidebar -->
    <div class="flex">
        <aside class="w-16 lg:w-20 bg-white border-r border-gray-200 h-screen flex flex-col items-center py-4">
            <div class="mb-8">
                <img src="https://via.placeholder.com/40" alt="Logo" class="w-10 h-10">
            </div>
            <nav class="flex flex-col space-y-4">
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-chart-grid text-xl"></i></button>
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-user text-xl"></i></button>
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-calendar-check text-xl"></i></button>
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-dollar-sign text-xl"></i></button>
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-receipt text-xl"></i></button>
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-flask text-xl"></i></button>
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-pen text-xl"></i></button>
                <button class="text-gray-500 hover:text-blue-500"><i class="fas fa-image text-xl"></i></button>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="flex-1 p-6">
            <!-- Header -->
            <div class="flex justify-between items-center mb-6">
                <h1 class="text-2xl font-semibold">Data Pasien</h1>
                <div class="flex items-center space-x-4">
                    <span class="text-gray-500">Nabila Huwaida</span>
                    <span class="text-gray-400 text-sm">Admin</span>
                </div>
            </div>

            <!-- Card -->
            <div class="bg-white rounded-lg shadow p-4 w-80 mb-6 border border-blue-200">
                <div class="flex items-center space-x-4 bg-pink-50 p-4 rounded-lg">
                    <div class="bg-blue-100 p-3 rounded-lg">
                        <i class="fas fa-bed text-blue-500 text-2xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-500">Total Pasien</p>
                        <p class="text-xl font-semibold">1220</p>
                    </div>
                </div>
                <div class="mt-4 text-sm text-gray-600">
                    <p>Total pasien : 21</p>
                    <p>30 Hari Terakhir : 231</p>
                </div>
            </div>

            <!-- Table -->
            <div class="overflow-x-auto bg-white rounded-lg shadow">
                <table class="min-w-full text-left border-collapse">
                    <thead class="bg-pink-50">
                        <tr>
                            <th class="py-3 px-4 text-sm font-medium text-gray-700">No. RM</th>
                            <th class="py-3 px-4 text-sm font-medium text-gray-700">Nama Pasien</th>
                            <th class="py-3 px-4 text-sm font-medium text-gray-700">NIK</th>
                            <th class="py-3 px-4 text-sm font-medium text-gray-700">L/P</th>
                            <th class="py-3 px-4 text-sm font-medium text-gray-700">Umur</th>
                            <th class="py-3 px-4 text-sm font-medium text-gray-700">No. Telepon</th>
                            <th class="py-3 px-4 text-sm font-medium text-gray-700">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="py-2 px-4">RM-2024-001</td>
                            <td class="py-2 px-4">Budi Santoso</td>
                            <td class="py-2 px-4">3174012345670001</td>
                            <td class="py-2 px-4">L</td>
                            <td class="py-2 px-4">39 Tahun</td>
                            <td class="py-2 px-4">0812-3456-7890</td>
                            <td class="py-2 px-4 text-gray-500 hover:text-gray-800 cursor-pointer">
                                <i class="fas fa-eye"></i>
                            </td>
                        </tr>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="py-2 px-4">RM-2024-001</td>
                            <td class="py-2 px-4">Budi Santoso</td>
                            <td class="py-2 px-4">3174012345670001</td>
                            <td class="py-2 px-4">L</td>
                            <td class="py-2 px-4">39 Tahun</td>
                            <td class="py-2 px-4">0812-3456-7890</td>
                            <td class="py-2 px-4 text-gray-500 hover:text-gray-800 cursor-pointer">
                                <i class="fas fa-eye"></i>
                            </td>
                        </tr>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="py-2 px-4">RM-2024-001</td>
                            <td class="py-2 px-4">Budi Santoso</td>
                            <td class="py-2 px-4">3174012345670001</td>
                            <td class="py-2 px-4">L</td>
                            <td class="py-2 px-4">39 Tahun</td>
                            <td class="py-2 px-4">0812-3456-7890</td>
                            <td class="py-2 px-4 text-gray-500 hover:text-gray-800 cursor-pointer">
                                <i class="fas fa-eye"></i>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </main>
    </div>

</body>
</html>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/pages/admin/pengguna.blade.php ENDPATH**/ ?>