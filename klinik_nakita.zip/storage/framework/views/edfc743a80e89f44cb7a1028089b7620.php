<?php if (isset($component)) { $__componentOriginalefa1d248efab4e1ce8988fc029e1702d = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalefa1d248efab4e1ce8988fc029e1702d = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layouts.auth.split','data' => ['title' => $title ?? null]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layouts.auth.split'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($title ?? null)]); ?>
    <?php if(session('success')): ?>
        <div class="mb-4 px-4 py-3 bg-green-100 border border-green-300 text-green-800 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php elseif(session('error')): ?>
        <div class="mb-4 px-4 py-3 bg-red-100 border border-red-300 text-red-800 rounded">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php echo e($slot); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalefa1d248efab4e1ce8988fc029e1702d)): ?>
<?php $attributes = $__attributesOriginalefa1d248efab4e1ce8988fc029e1702d; ?>
<?php unset($__attributesOriginalefa1d248efab4e1ce8988fc029e1702d); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalefa1d248efab4e1ce8988fc029e1702d)): ?>
<?php $component = $__componentOriginalefa1d248efab4e1ce8988fc029e1702d; ?>
<?php unset($__componentOriginalefa1d248efab4e1ce8988fc029e1702d); ?>
<?php endif; ?>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/components/layouts/auth.blade.php ENDPATH**/ ?>