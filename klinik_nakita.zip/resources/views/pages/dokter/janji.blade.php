<x-layouts.app :title="__('Janji')">
    @livewire('pages.dokter.janji')
</x-layouts.app>
