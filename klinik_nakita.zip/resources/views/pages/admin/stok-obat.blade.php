<x-layouts.app :title="__('Stok')">
    @livewire('pages.admin.stok-obat')
</x-layouts.app>
