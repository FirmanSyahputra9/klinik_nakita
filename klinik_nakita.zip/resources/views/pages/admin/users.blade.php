<x-layouts.app :title="__('Pengguna')">
    @livewire('pages.admin.user')
</x-layouts.app>
