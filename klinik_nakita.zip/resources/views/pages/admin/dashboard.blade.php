<x-layouts.app :title="__('Dashboard')">
    <!-- Dashboard Cards -->
    @livewire('admin-dashboard')
</x-layouts.app>
