<x-layouts.app :title="__('Jadwal')">
    @livewire('pages.pasien.jadwal')
</x-layouts.app>
