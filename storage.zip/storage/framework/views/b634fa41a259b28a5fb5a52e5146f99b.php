

<div <?php echo e($attributes->class('flex-1')); ?> data-flux-spacer></div>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\vendor\livewire\flux\src/../stubs/resources/views/flux/spacer.blade.php ENDPATH**/ ?>