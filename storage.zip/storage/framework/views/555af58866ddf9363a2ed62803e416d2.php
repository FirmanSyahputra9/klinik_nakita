

<ui-close data-flux-modal-close>
    <?php echo e($slot); ?>

</ui-close>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\vendor\livewire\flux\src/../stubs/resources/views/flux/modal/close.blade.php ENDPATH**/ ?>