<div class="p-6">

    <!-- TOP CARDS -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <!-- Total Pasien -->
        <div class="card bg-white dark:bg-gray-900 rounded-xl shadow p-4 border border-gray-200">
            <div class="card flex items-center mb-4">
                <div class="bg-blue-200 dark:bg-gray-600 p-3 rounded-full mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-blue-500 dark:text-gray-100" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 12a4 4 0 100-8 4 4 0 000 8z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M6 20a6 6 0 1112 0H6z" />
                    </svg>
                </div>
                <div>
                    <h2 class="card text-gray-800 dark:text-gray-100 font-bold text-lg">Akun Pasien</h2>
                    <p class="card text-gray-500 text-sm"><?php echo e($totalPengguna ?? '0'); ?></p>
                </div>
            </div>

            <div class="card text-gray-500 text-sm">
                <p>Pasien Hari Ini: <?php echo e($penggunaHariIni?? '0'); ?></p>
                <p>30 Hari Terakhir: <?php echo e($penggunaBaru?? '0'); ?></p>
            </div>
        </div>

        <!-- Total Dokter -->
        <div class="card bg-pink-100 dark:bg-gray-800 rounded-xl shadow p-4 border border-gray-200">
            <div class="card flex items-center mb-4">
                <div class="bg-pink-200 dark:bg-gray-600 p-3 rounded-full mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-pink-500 dark:text-gray-100" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 14l9-5-9-5-9 5 9 5z" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 14l6.16-3.422A12.083 12.083 0 0121 14.094M12 14v7.5" />
                    </svg>
                </div>
                <div>
                    <h2 class="card text-gray-800 dark:text-gray-100 font-bold text-lg">Total Dokter</h2>
                    <p class="card text-gray-500 text-sm"><?php echo e($totalDokter?? '0'); ?></p>
                </div>
            </div>
            <div class="card text-gray-500 text-sm">
                <p>Spesialis: <?php echo e($dokterSpesialis?? '0'); ?></p>
                <p>Umum: <?php echo e($dokterUmum?? '0'); ?></p>
            </div>
        </div>

        <!-- Total Janji -->
        <div class="card bg-white dark:bg-gray-900 rounded-xl shadow p-4 border border-gray-200">
            <div class="card flex items-center mb-4">
                <div class="bg-blue-100 dark:bg-gray-600 p-3 rounded-full mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-blue-500 dark:text-gray-100" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3M16 7V3M3 11h18M5 11v10h14V11" />
                    </svg>
                </div>
                <div>
                    <h2 class="card text-gray-800 dark:text-gray-100 font-bold text-lg">Total Janji</h2>
                    <p class="card text-gray-500 text-sm"><?php echo e($totalJanji??'0'); ?></p>
                </div>
            </div>
            <div class="card text-gray-500 text-sm">
                <p>Registrasi Hari Ini: <?php echo e($totalJanjiHariIni??'0'); ?></p>
                <p>30 Hari Terakhir: <?php echo e($totalJanjiBaru??'0'); ?></p>
            </div>
        </div>

        <!-- Stok Obat -->
        <div class="card bg-pink-100 dark:bg-gray-800 rounded-xl shadow p-4 border border-gray-200">
            <div class="card flex items-center mb-4">
                <div class="bg-pink-100 dark:bg-gray-900 p-3 rounded-full mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 text-pink-500 dark:text-gray-100" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M20 13V7a2 2 0 00-2-2H6a2 2 0 00-2 2v6" />
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 16v6m3-3H9" />
                    </svg>
                </div>
                <div>
                    <h2 class="card text-gray-800 dark:text-gray-100 font-bold text-lg">Stok Obat</h2>
                    <p class="card text-gray-500 text-sm">Total: <?php echo e($totalObat?? '0'); ?></p>
                    <p class="card text-gray-500 text-sm">Sedikit: <?php echo e($obatSisaSedikit?? '0'); ?></p>
                    <p class="card text-gray-500 text-sm">Habis: <?php echo e($obatHabis?? '0'); ?></p>
                </div>
            </div>
        </div>

    </div>

    <!-- MAIN CONTENT AREA -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- LEFT SIDE (APPOINTMENTS + OBAT) -->
        <div class="lg:col-span-2 space-y-10">

            <!-- TABLE APPOINTMENTS -->
            <div class="card bg-white dark:bg-gray-800 rounded-xl shadow p-6 border border-gray-200">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('appointment-short');

$__html = app('livewire')->mount($__name, $__params, 'lw-2916592303-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>

            <!-- Short Table: Dokter Aktif -->
            <div class="card bg-white dark:bg-gray-800 rounded-xl shadow p-6 border border-gray-200 mt-10">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('pages.short.dokter-aktif');

$__html = app('livewire')->mount($__name, $__params, 'lw-2916592303-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>

        </div>

        <!-- RIGHT SIDE -->
        <div class="card bg-white dark:bg-gray-800 rounded-xl shadow p-6 border border-gray-200 flex flex-col items-center justify-start self-start space-y-6">

            <!-- CLOCK -->
            <div class="card w-full text-centerc ">
                <h2 class="card text-lg font-bold text-gray-800 dark:text-white mb-3">Jam Sekarang</h2>

                <div class="card flex items-center gap-2 bg-blue-200 dark:bg-gray-900 p-3 rounded-lg shadow-inner justify-center border border-gray-200">
                    <div id="h"
                        class="card px-4 py-2 bg-white rounded-md shadow text-3xl font-bold text-blue-700 dark:text-gray-800 min-w-[70px] text-center">
                        00
                    </div>

                    <span class="card text-3xl font-bold text-blue-700 dark:text-gray-100 pb-1">:</span>

                    <div id="m"
                        class="card px-4 py-2 bg-white rounded-md shadow text-3xl font-bold text-blue-700 dark:text-gray-800 min-w-[70px] text-center">
                        00
                    </div>

                    <span class="card text-3xl font-bold text-blue-700 dark:text-gray-100 pb-1">:</span>
                    <div id="s"
                        class="card px-4 py-2 bg-white rounded-md shadow text-3xl font-bold text-blue-700 dark:text-gray-800 min-w-[70px] text-center">
                        00
                    </div>
                </div>
            </div>

            <script>
                setInterval(() => {
                    const now = new Date();

                    document.getElementById('h').textContent =
                        String(now.getHours()).padStart(2, '0');
                    document.getElementById('m').textContent =
                        String(now.getMinutes()).padStart(2, '0');
                    document.getElementById('s').textContent =
                        String(now.getSeconds()).padStart(2, '0');
                }, 1000);
            </script>

            <!-- ACTION CARDS -->
            <div class="w-full space-y-4">

                <!-- Card 1 -->
                <a href="<?php echo e(route('users.index')); ?>"
                    class="card block bg-blue-100 dark:bg-gray-600 hover:bg-blue-200 dark:hover:bg-gray-700 transition rounded-xl p-4 shadow border border-blue-200 dark:border-gray-100">
                    <h3 class="card text-blue-900 dark:text-white font-semibold text-md">Lihat User</h3>
                    <p class="card hover:underline text-blue-700 dark:text-white text-sm mt-1">Kelola Data Pasien</p>
                </a>

                <!-- Card 2 -->
                <a href="<?php echo e(route('kasir.index')); ?>"
                    class="block bg-pink-100 dark:bg-gray-600 hover:bg-pink-200 dark:hover:bg-gray-700 transition rounded-xl p-4 shadow border border-pink-200 dark:border-gray-100">
                    <h3 class="text-pink-900 dark:text-white font-semibold text-md">Cek Riwayat Pembayaran</h3>
                    <p class="hover:underline text-pink-700 dark:text-white text-sm mt-1">Pantau transaksi dan pembayaran pasien.</p>
                </a>

                <!-- Card 3 -->
                <a href="<?php echo e(route('stok-obat.index')); ?>"
                    class="block bg-yellow-100 dark:bg-gray-600 hover:bg-yellow-200 dark:hover:bg-gray-700 transition rounded-xl p-4 shadow border border-yellow-200 dark:border-gray-100">
                    <h3 class="text-yellow-900 dark:text-white font-semibold text-md">Cek Stok Obat</h3>
                    <p class="hover:underline text-yellow-700 dark:text-white text-sm mt-1">Lihat jumlah stok obat dan status ketersediaan.</p>
                </a>

            </div>

        </div>



    </div>

</div><?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/livewire/admin-dashboard.blade.php ENDPATH**/ ?>