<div class="dark:bg-gray-800">
    <h2 class="text-lg font-bold text-gray-800 dark:text-gray-100 mb-4">Dokter Aktif (<?php echo e($jadwalsTotal); ?>)</h2>

    <div class="overflow-x-auto">
        <table class="w-full text-xs uppercase border border-gray-300 rounded-lg whitespace-nowrap ">
            <thead class="bg-gray-200 text-gray-700 dark:text-white dark:bg-gray-600 dark:border-y">
                <tr>
                    <th class="px-4 py-2 text-left">Nama Lengkap</th>
                    <th class="px-4 py-2 text-left">Spesialisasi</th>
                    <th class="px-4 py-2 text-left">No. Telepon</th>
                    <th class="px-4 py-2 text-left">Email</th>
                    <th class="px-4 py-2 text-left">Jadwal</th>
                </tr>
            </thead>

            <tbody class="bg-white dark:bg-gray-800 divide-y">
                <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $jadwals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white"">
                        <td class="px-4 py-2 min-w-32 max-w-32 overflow-x-auto thin-scroll"><?php echo e($item->dokter->name); ?></td>
                        <td class="px-4 py-2 min-w-32 max-w-32 overflow-x-auto thin-scroll"><?php echo e($item->dokter->spesialisasi); ?></td>
                        <td class="px-4 py-2 min-w-32 max-w-32 overflow-x-auto thin-scroll"><?php echo e($item->dokter->phone); ?></td>
                        <td class="px-4 py-2 min-w-32 max-w-32 overflow-x-auto thin-scroll"><?php echo e($item->dokter->user->email); ?></td>
                        <td class="px-4 py-2 min-w-32 max-w-32 overflow-x-auto thin-scroll"><?php echo e($item->mulai_aktif); ?> - <?php echo e($item->selesai_aktif); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-6 text-gray-400">
                            Tidak ada jadwal dokter untuk hari ini
                        </td>
                    </tr>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
    </div>
    <div><?php echo e($jadwals->links('pagination::tailwind')); ?></div>
</div>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/livewire//pages/short/dokter-aktif.blade.php ENDPATH**/ ?>