<div>
    <div x-data="stokFilter()">

        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-semibold text-gray-800 dark:text-gray-100">Stok Obat</h1>

            <a href="<?php echo e(route('stok-obat.create')); ?>"
                class="flex items-center gap-2 bg-blue-600 dark:bg-gray-800 text-white dark:text-gray-100 px-4 py-2 rounded-lg hover:bg-blue-700 dark:hover:bg-gray-900 transition">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" stroke="currentColor"
                    viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                </svg>
                Tambah Obat
            </a>
        </div>

        <!-- Search & Filter -->
        <div class="mb-4 flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">

            <!-- SEARCH -->
            <div class="relative w-full sm:w-64">
                <input type="text" wire:model.live="search" x-model="search" placeholder="Cari kode, nama, satuan..."
                    class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <!-- FILTER -->
            <div class="flex gap-3">

                <!-- Filter Satuan -->
                <select  wire:model.live="filterSatuan"
                    class="px-3 py-2 border rounded-lg text-sm text-gray-700 dark:focus:bg-gray-700 dark:text-white focus:ring focus:ring-blue-200 dark:focus:ring-gray-200">
                    <option value="">Semua Satuan</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $satuan??[]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s); ?>"><?php echo e($s); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>

                <!-- Filter Stok -->
                <select x-model="filterStok"
                    class="px-3 py-2 border rounded-lg text-sm text-gray-700 dark:focus:bg-gray-700 dark:text-white focus:ring focus:ring-blue-200 dark:focus:ring-gray-200">
                    <option value="">Semua Stok</option>
                    <option value="low">Stok Menipis (≤ 10)</option>
                    <option value="safe">Stok Aman (> 10)</option>
                </select>

            </div>

        </div>

        <!-- TABLE -->
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow overflow-x-auto">
            <table class="min-w-full text-sm text-left text-gray-600">
                <thead class="bg-blue-50 text-gray-700 uppercase text-xs font-semibold dark:text-white dark:bg-gray-600 dark:border-y">
                    <tr>
                        <th class="px-4 py-3">Kode</th>
                        <th class="px-4 py-3">Nama Obat</th>
                        <th class="px-4 py-3">Stok</th>
                        <th class="px-4 py-3">Satuan</th>
                        <th class="px-4 py-3">Harga Beli</th>
                        <th class="px-4 py-3">Harga Jual</th>
                        <th class="px-4 py-3">Kadaluwarsa</th>
                        <th class="px-4 py-3 text-center">Aksi</th>
                    </tr>
                </thead>

                <tbody>

                    <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $obats??[]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="border-b hover:bg-gray-50 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white"
                            x-show="match({
                            kode: '<?php echo e(strtolower($obat->kode)); ?>',
                            nama: '<?php echo e(strtolower($obat->nama)); ?>',
                            satuan: '<?php echo e(strtolower($obat->satuan)); ?>',
                            stok: <?php echo e($obat->stok); ?>

                        })">
                            <td class="px-4 py-3 font-medium"><?php echo e($obat->kode); ?></td>
                            <td class="px-4 py-3"><?php echo e($obat->nama); ?></td>
                            <td class="px-4 py-3"><?php echo e($obat->stok); ?></td>
                            <td class="px-4 py-3"><?php echo e($obat->satuan); ?></td>
                            <td class="px-4 py-3">Rp <?php echo e(number_format($obat->harga_beli, 0, ',', '.')); ?></td>
                            <td class="px-4 py-3">Rp <?php echo e(number_format($obat->harga_jual, 0, ',', '.')); ?></td>
                            <td class="px-4 py-3">
                                <?php echo e(\Carbon\Carbon::parse($obat->tanggal_kadaluwarsa)->format('d M Y')); ?>

                            </td>

                            <td class="px-4 py-3 text-center flex justify-center gap-2">

                                <!-- EDIT BUTTON -->
                                <button class="p-2 bg-green-500 dark:bg-gray-600 text-white rounded hover:bg-green-600 dark:hover:bg-gray-800 transition"
                                    x-on:click="
                                    openEdit({
                                        id: '<?php echo e($obat->id); ?>',
                                        kode: '<?php echo e($obat->kode); ?>',
                                        nama: '<?php echo e($obat->nama); ?>',
                                        stok: '<?php echo e($obat->stok); ?>',
                                        satuan: '<?php echo e($obat->satuan); ?>',
                                        harga_beli: '<?php echo e($obat->harga_beli); ?>',
                                        harga_jual: '<?php echo e($obat->harga_jual); ?>',
                                        tanggal_kadaluwarsa: '<?php echo e($obat->tanggal_kadaluwarsa); ?>'
                                    })
                                ">
                                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                        stroke-width="1.5" stroke="currentColor" class="size-3">
                                        <path stroke-linecap="round" stroke-linejoin="round" d="m16.862 4.487 1.687-1.688a1.875 1.875
                                        0 1 1 2.652 2.652L6.832 19.82a4.5 4.5
                                        0 0 1-1.897 1.13l-2.685.8.8-2.685a4.5
                                        4.5 0 0 1 1.13-1.897L16.863 4.487Z" />
                                    </svg>
                                </button>

                                <!-- DELETE BUTTON -->
                                <form action="<?php echo e(route('stok-obat.destroy', $obat->id)); ?>" method="POST"
                                    onsubmit="return confirm('Hapus obat ini?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit"
                                        class="p-2 bg-red-500 dark:bg-gray-600 text-white rounded hover:bg-red-600 dark:hover:bg-gray-800 transition">
                                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                            stroke-width="1.5" stroke="currentColor" class="size-3">
                                            <path stroke-linecap="round" stroke-linejoin="round" d="m14.74 9-.346 9m-4.788
                                            0L9.26 9m9.968-3.21c.342.052.682.107
                                            1.022.166M4.772 5.79a48.11
                                            48.11 0 0 1 3.478-.397m7.5
                                            0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964
                                            51.964 0 0 0-3.32 0c-1.18.037-2.09
                                            1.022-2.09 2.201v.916" />
                                        </svg>
                                    </button>
                                </form>

                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="8" class="text-center py-6 text-gray-400">
                                Tidak ada data obat
                            </td>
                        </tr>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                </tbody>
            </table>
        </div>

        <div class="mt-6">
            <?php echo e($obats?->links('pagination::tailwind')); ?>

        </div>


        <!-- EDIT MODAL -->
        <div x-show="showEdit" x-transition class="fixed inset-0 bg-black/40 flex items-center justify-center p-4">
            <div class="bg-white rounded-lg p-6 w-full max-w-lg">

                <h2 class="text-xl font-semibold mb-4">Edit Obat</h2>

                <form method="POST" :action="'/admin/stok-obat/' + id">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="text-sm font-medium">Kode</label>
                            <input type="text" class="w-full border rounded p-2" x-model="kode" name="kode">
                        </div>

                        <div>
                            <label class="text-sm font-medium">Nama</label>
                            <input type="text" class="w-full border rounded p-2" x-model="nama" name="nama">
                        </div>

                        <div>
                            <label class="text-sm font-medium">Stok</label>
                            <input type="number" class="w-full border rounded p-2" x-model="stok" name="stok">
                        </div>

                        <div>
                            <label class="text-sm font-medium">Satuan</label>
                            <input type="text" class="w-full border rounded p-2" x-model="satuan" name="satuan">
                        </div>

                        <div>
                            <label class="text-sm font-medium">Harga Beli</label>
                            <input type="number" class="w-full border rounded p-2" x-model="harga_beli"
                                name="harga_beli">
                        </div>

                        <div>
                            <label class="text-sm font-medium">Harga Jual</label>
                            <input type="number" class="w-full border rounded p-2" x-model="harga_jual"
                                name="harga_jual">
                        </div>

                        <div class="col-span-2">
                            <label class="text-sm font-medium">Tanggal Kadaluwarsa</label>
                            <input type="date" class="w-full border rounded p-2" x-model="tgl"
                                name="tanggal_kadaluwarsa">
                        </div>
                    </div>

                    <div class="flex justify-end mt-6 gap-2">
                        <button type="button" class="px-4 py-2 bg-gray-300 rounded hover:bg-gray-400"
                            x-on:click="showEdit = false">
                            Batal
                        </button>

                        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                            Simpan
                        </button>
                    </div>
                </form>

            </div>
        </div>

    </div>

    <!-- ALPINE FILTER SCRIPT -->
    <script>
        function stokFilter() {
            return {
                showEdit: false,
                id: '',
                kode: '',
                nama: '',
                stok: '',
                satuan: '',
                harga_beli: '',
                harga_jual: '',
                tgl: '',

                search: "",
                filterSatuan: "",
                filterStok: "",

                openEdit(obat) {
                    this.showEdit = true;
                    this.id = obat.id;
                    this.kode = obat.kode;
                    this.nama = obat.nama;
                    this.stok = obat.stok;
                    this.satuan = obat.satuan;
                    this.harga_beli = obat.harga_beli;
                    this.harga_jual = obat.harga_jual;
                    this.tgl = obat.tanggal_kadaluwarsa;
                },

                match(obat) {
                    let s = this.search.toLowerCase();

                    let okSearch =
                        obat.kode.includes(s) ||
                        obat.nama.includes(s) ||
                        obat.satuan.includes(s);

                    let okSatuan =
                        this.filterSatuan === "" ||
                        obat.satuan === this.filterSatuan;

                    let okStok = true;
                    if (this.filterStok === "low") okStok = obat.stok <= 10;
                    if (this.filterStok === "safe") okStok = obat.stok > 10;

                    return okSearch && okSatuan && okStok;
                }
            }
        }
    </script>
</div>
<?php /**PATH F:\MATERI\S5\Managemen_Proyek_TI\NAKITA\klinik_nakita\resources\views/livewire/pages/admin/stok-obat.blade.php ENDPATH**/ ?>