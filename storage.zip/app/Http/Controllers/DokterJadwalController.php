<?php

namespace App\Http\Controllers;

use App\Models\Dokter;
use App\Models\DokterJadwal;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;

class DokterJadwalController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $dokterJadwals = Dokter::whereHas('jadwals')->where('user_id', Auth::User()->id)->first();
        if (!$dokterJadwals) {
            $dokterJadwals = new Dokter();
            $dokterJadwals->setRelation('jadwals', collect());
        }
        return view('pages.dokter.jadwal', compact('dokterJadwals'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(DokterJadwal $dokterJadwal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(DokterJadwal $dokterJadwal)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, DokterJadwal $dokterJadwal)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(DokterJadwal $dokterJadwal)
    {
        //
    }
}
