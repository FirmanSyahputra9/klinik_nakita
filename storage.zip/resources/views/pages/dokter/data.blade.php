<x-layouts.app :title="__('Data')">
    @livewire('pages.dokter.data-pasien')

</x-layouts.app>
