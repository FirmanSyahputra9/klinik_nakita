<x-layouts.app :title="__('Registrasi')">

    @livewire('pages.admin.registrasi-pasien')

</x-layouts.app>
